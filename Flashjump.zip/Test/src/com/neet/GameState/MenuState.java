package com.neet.GameState;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import com.neet.Audio.JukeBox;
import com.neet.Entity.PlayerSave;
import com.neet.Handlers.Keys;
import com.neet.Main.GamePanel;

public class MenuState extends GameState {
	
	private BufferedImage head;
	
	private int currentChoice = 0;
	private String[] options = {
		"Beginne das Spiel!",
		"Beende das Spiel! :("
	};
	
	private Color titleColor;
	private Font titleFont;
	
	private Font font;
	private Font font2;
	
	public MenuState(GameStateManager gsm) {
		
		super(gsm);
		
		try {
			
			// load floating head
			head = ImageIO.read(
				getClass().getResourceAsStream("/HUD/Hud.gif")
			).getSubimage(0, 12, 12, 11);
			
			// titles and fonts
			titleColor = Color.orange;
			titleFont = new Font("Times New Roman", Font.PLAIN, 28);
			font = new Font("Arial", Font.PLAIN, 14);
			font2 = new Font("Arial", Font.PLAIN, 10);
			
			// load sound fx
			JukeBox.load("/SFX/menuoption.mp3", "menuoption");
			JukeBox.load("/SFX/menuselect.mp3", "menuselect");
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void init() {}
	
	public void update() {
		
		// check keys
		handleInput();
		
	}
	
	public void draw(Graphics2D g) {
		
		// draw bg
		g.setColor(Color.GRAY);
		g.fillRect(0, 0, GamePanel.WIDTH, GamePanel.HEIGHT);
		
		// draw title
		g.setColor(titleColor);
		g.setFont(titleFont);
		g.drawString("F L A S H J U M P", 60, 90);

		if(currentChoice == 0) g.setColor(Color.green);
		// else if(currentChoice == 1) g.setColor(Color.red);

		// draw menu options
		g.setFont(font);
		// g.setColor(Color.WHITE);
		g.drawString("↑ Beginne das Spiel!", 80, 125);
		g.setColor(Color.white);
		g.drawString("↓ Beende das Spiel! :(", 80, 145);
		if(currentChoice == 1) g.drawString("Bist du sicher?", 100, 165);
		if(currentChoice == 1) {
			g.setColor(Color.black);
			g.fillRect(0, 0, GamePanel.WIDTH, GamePanel.HEIGHT);
			g.setColor(Color.red);
			g.drawString("Möchtest du wirklich beenden?", 70, 125);
			g.setColor(titleColor);
			g.setFont(titleFont);
			g.drawString("F L A S H J U M P", 60, 90);


		}
		
		// draw floating head


		// other
		g.setFont(font2);
		g.setColor(Color.WHITE);
		g.drawString("Die Codelosen", 6, 212);
		g.drawString("Informatikprojekt", 6, 202);
		g.drawString(" -> Kay Z., Kai L. ", 3, 222);
		g.drawString(" -> Marc. O Dominic E.", 3, 232);
		g.drawString(" 2. Halbjahr 2022", 230, 232);

	}
	
	private void select() {
		if(currentChoice == 0) {
			JukeBox.play("menuselect");
			PlayerSave.init();
			gsm.setState(GameStateManager.LEVEL1ASTATE);
		}
		else if(currentChoice == 1) {
			System.exit(0);
		}
	}
	
	public void handleInput() {
		if(Keys.isPressed(Keys.ENTER)) select();
		if(Keys.isPressed(Keys.UP)) {
			if(currentChoice > 0) {
				JukeBox.play("menuoption", 0);
				currentChoice--;
			}
		}
		if(Keys.isPressed(Keys.DOWN)) {
			if(currentChoice < options.length - 1) {
				JukeBox.play("menuoption", 0);
				currentChoice++;
			}
		}
	}
	
}










